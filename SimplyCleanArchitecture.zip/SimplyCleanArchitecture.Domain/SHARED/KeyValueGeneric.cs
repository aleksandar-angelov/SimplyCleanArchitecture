﻿namespace $safeprojectname$.Shared;

public class KeyValueGeneric<TKey, TValue>
{
    public TKey Id { get; set; }

    public TValue Value { get; set; }
}
