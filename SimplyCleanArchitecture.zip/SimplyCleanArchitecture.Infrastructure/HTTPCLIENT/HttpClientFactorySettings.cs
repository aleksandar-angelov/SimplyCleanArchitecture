﻿namespace Aspekt.KICBIntegrations.Infrastructure.HttpClient;
public sealed class HttpClientFactorySettings
{
        public string HttpClientName { get; set; }
        public string HttpClientBaseAddress { get; set; }    
}
