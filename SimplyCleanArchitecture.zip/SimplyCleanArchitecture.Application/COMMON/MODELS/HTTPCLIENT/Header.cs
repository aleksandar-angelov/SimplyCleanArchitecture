﻿namespace $safeprojectname$.Common.Models.HttpClient;

public sealed record Header(string Key, string Value);
