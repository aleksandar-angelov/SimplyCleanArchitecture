﻿
using SimplyCleanArchitecture.Domain.Shared;

namespace $safeprojectname$.Common.Models.Cache;

public class CacheModel
{
    List<KeyValueGeneric<string, string>> CacheData { get; set; }
}
