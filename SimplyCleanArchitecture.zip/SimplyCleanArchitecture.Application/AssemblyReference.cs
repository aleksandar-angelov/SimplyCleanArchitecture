﻿namespace $safeprojectname$;

internal static class AssemblyReference
{
}
